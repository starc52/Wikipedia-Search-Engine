#!/bin/bash
python index.py "$1" "$2" "$3"
