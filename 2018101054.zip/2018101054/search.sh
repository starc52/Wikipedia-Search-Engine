#!/bin/bash
python search.py "$1" "$2"
